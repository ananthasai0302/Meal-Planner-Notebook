"""Reports in Markdown, plain text and CSV."""

import csv
import io
from datetime import datetime
from pathlib import Path

from .planner import build_grocery_list, build_week_plan, pretty_quantity
from .summary import DEFAULT_LIMIT, compute_summary, get_warnings
from .validation import DAYS, MEAL_TYPES


def _stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def to_markdown(meals, limit=DEFAULT_LIMIT):
    summary = compute_summary(meals, limit)
    plan = build_week_plan(meals)
    lines = ["# Weekly Meal Plan Report", ""]
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- Total meals: {summary['total_meals']}")
    lines.append(f"- Total calories (one person): {summary['total_calories']}")
    lines.append(f"- Average per planned day: {summary['avg_per_planned_day']} kcal")
    lines.append(f"- Average per meal: {summary['avg_per_meal']} kcal")
    lines.append("")
    lines.append("## Daily Overview")
    lines.append("")
    lines.append("| Day | Calories | Status |")
    lines.append("|-----|----------|--------|")
    for day in DAYS:
        lines.append(f"| {day} | {summary['daily_totals'][day]} | {summary['daily_status'][day]} |")
    lines.append("")
    lines.append("## Meals")
    lines.append("")
    for day in DAYS:
        lines.append(f"### {day}")
        for kind in MEAL_TYPES:
            for meal in plan[day][kind]:
                lines.append(f"- **{kind}**: {meal.name} ({meal.calories} kcal, {meal.servings} serving(s))")
        lines.append("")
    lines.append("## Grocery List")
    lines.append("")
    for name, qty, unit in build_grocery_list(meals):
        lines.append(f"- {name}: {pretty_quantity(qty, unit)}")
    lines.append("")
    lines.append("## Warnings")
    lines.append("")
    warnings = get_warnings(meals, limit)
    if warnings:
        lines.extend(f"- {w}" for w in warnings)
    else:
        lines.append("- None")
    return "\n".join(lines) + "\n"


def to_text(meals, limit=DEFAULT_LIMIT):
    summary = compute_summary(meals, limit)
    lines = ["WEEKLY MEAL PLAN - AUDIT LOG", "=" * 40]
    lines.append(f"Generated : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"Meals     : {summary['total_meals']}")
    lines.append(f"Calories  : {summary['total_calories']} total, {summary['avg_per_planned_day']} per planned day")
    lines.append("")
    for day in DAYS:
        lines.append(f"{day:<10} {summary['daily_totals'][day]:>5} kcal  [{summary['daily_status'][day]}]")
    lines.append("")
    lines.append("WARNINGS")
    warnings = get_warnings(meals, limit)
    if warnings:
        lines.extend(f"  * {w}" for w in warnings)
    else:
        lines.append("  none")
    lines.append("")
    lines.append("GROCERY LIST")
    for name, qty, unit in build_grocery_list(meals):
        lines.append(f"  - {name}: {pretty_quantity(qty, unit)}")
    return "\n".join(lines) + "\n"


def to_csv_text(meals):
    """CSV in the same layout the importer reads, so exports can be re-imported."""
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\n")
    writer.writerow(["day", "meal_type", "name", "category", "calories", "servings", "ingredients"])
    for meal in meals:
        writer.writerow([meal.day, meal.meal_type, meal.name, meal.category,
                         meal.calories, meal.servings, meal.ingredients_text()])
    return buffer.getvalue()


def export_all(meals, folder, limit=DEFAULT_LIMIT):
    """Write .md, .txt and .csv reports into `folder`; returns the file paths."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    stamp = _stamp()
    outputs = {
        folder / f"meal_report_{stamp}.md": to_markdown(meals, limit),
        folder / f"meal_audit_{stamp}.txt": to_text(meals, limit),
        folder / f"meal_data_{stamp}.csv": to_csv_text(meals),
    }
    for path, content in outputs.items():
        with open(path, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
    return list(outputs.keys())
