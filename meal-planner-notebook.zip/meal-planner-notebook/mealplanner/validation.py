"""Input cleaning and the loop helpers that keep asking until input is valid.

The clean_* functions raise ValueError with a readable message. They are
used both by the terminal prompts and by the CSV importer.
"""

import re

from .models import Ingredient

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MEAL_TYPES = ["Breakfast", "Lunch", "Dinner", "Snack"]
CATEGORIES = ["Vegetarian", "Vegan", "Eggetarian", "Non-Vegetarian"]
UNITS = ["g", "kg", "ml", "l", "pcs", "tbsp", "tsp", "cup"]

MIN_CALORIES, MAX_CALORIES = 0, 3000
MIN_SERVINGS, MAX_SERVINGS = 1, 20
MAX_INGREDIENTS = 20

NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 '&,()\-]*$")


class CancelledEntry(Exception):
    """Raised when the user types 'cancel' during a prompt."""


def _match_option(value, options, label):
    text = str(value).strip().lower()
    if not text:
        raise ValueError(f"{label} cannot be blank.")
    for option in options:
        if option.lower() == text:
            return option
    # allow short forms such as "mon" as long as they are unambiguous
    hits = [o for o in options if o.lower().startswith(text)]
    if len(text) >= 3 and len(hits) == 1:
        return hits[0]
    raise ValueError(f"{label} must be one of: {', '.join(options)}.")


def clean_day(value):
    return _match_option(value, DAYS, "Day")


def clean_meal_type(value):
    return _match_option(value, MEAL_TYPES, "Meal type")


def clean_category(value):
    return _match_option(value, CATEGORIES, "Category")


def clean_name(value):
    text = " ".join(str(value).split())
    if len(text) < 2 or len(text) > 50:
        raise ValueError("Name must be 2 to 50 characters long.")
    if not NAME_PATTERN.match(text):
        raise ValueError("Name may only use letters, digits, spaces and - ' & , ( )")
    return text


def _clean_int(value, low, high, label):
    text = str(value).strip()
    if not text:
        raise ValueError(f"{label} cannot be blank.")
    try:
        number = int(text)
    except ValueError:
        raise ValueError(f"{label} must be a whole number.") from None
    if number < low or number > high:
        raise ValueError(f"{label} must be between {low} and {high}.")
    return number


def clean_calories(value):
    return _clean_int(value, MIN_CALORIES, MAX_CALORIES, "Calories")


def clean_servings(value):
    return _clean_int(value, MIN_SERVINGS, MAX_SERVINGS, "Servings")


def parse_ingredients(text):
    """Turn 'rice:100:g; onion:1:pcs' into a list of Ingredient objects.

    Items can be separated by ';' or ','. Each item is name:quantity:unit and
    the quantity is per serving.
    """
    raw_items = [p.strip() for p in re.split(r"[;,]", str(text)) if p.strip()]
    if not raw_items:
        raise ValueError("Add at least one ingredient (format name:quantity:unit).")
    if len(raw_items) > MAX_INGREDIENTS:
        raise ValueError(f"A meal can have at most {MAX_INGREDIENTS} ingredients.")

    result = []
    for item in raw_items:
        parts = [p.strip() for p in item.split(":")]
        if len(parts) != 3:
            raise ValueError(f"'{item}' should look like name:quantity:unit.")
        name, qty_text, unit = parts
        if len(name) < 2 or len(name) > 40:
            raise ValueError(f"Ingredient name '{name}' must be 2 to 40 characters.")
        try:
            quantity = float(qty_text)
        except ValueError:
            raise ValueError(f"Quantity '{qty_text}' for {name} is not a number.") from None
        if not 0 < quantity <= 100000:   # also rejects nan
            raise ValueError(f"Quantity for {name} must be above 0 and at most 100000.")
        unit = unit.lower()
        if unit not in UNITS:
            raise ValueError(f"Unit '{unit}' is not supported. Use: {', '.join(UNITS)}.")
        result.append(Ingredient(name.lower(), quantity, unit))
    return result


def ask(prompt, cleaner, default=None):
    """Keep prompting until `cleaner` accepts the answer. 'cancel' aborts."""
    while True:
        suffix = f" [{default}]" if default is not None else ""
        answer = input(f"{prompt}{suffix}: ").strip()
        if answer.lower() == "cancel":
            raise CancelledEntry()
        if answer == "" and default is not None:
            answer = str(default)
        try:
            return cleaner(answer)
        except ValueError as problem:
            print(f"  ! {problem}")


def ask_optional(prompt, cleaner):
    """Like ask(), but a blank answer returns None (used for search filters)."""
    while True:
        answer = input(f"{prompt} (blank to skip): ").strip()
        if answer == "":
            return None
        try:
            return cleaner(answer)
        except ValueError as problem:
            print(f"  ! {problem}")
