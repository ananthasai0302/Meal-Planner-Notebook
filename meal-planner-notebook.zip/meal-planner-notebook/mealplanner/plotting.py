"""Charts with Matplotlib. If it is not installed we just say so."""

from pathlib import Path

from .summary import DEFAULT_LIMIT, compute_summary
from .validation import DAYS


def _load_pyplot():
    try:
        import matplotlib
        matplotlib.use("Agg")   # draw to files, no window needed
        import matplotlib.pyplot as plt
        return plt
    except ImportError:
        return None


def matplotlib_available():
    return _load_pyplot() is not None


def plot_daily_calories(meals, path, limit=DEFAULT_LIMIT):
    plt = _load_pyplot()
    if plt is None:
        return None
    summary = compute_summary(meals, limit)
    values = [summary["daily_totals"][d] for d in DAYS]
    colours = {"OK": "#4c9f70", "HIGH": "#d9534f", "LOW": "#f0ad4e", "EMPTY": "#bbbbbb"}
    bar_colours = [colours[summary["daily_status"][d]] for d in DAYS]

    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar([d[:3] for d in DAYS], values, color=bar_colours)
    ax.axhline(limit, color="black", linestyle="--", linewidth=1, label=f"Limit ({limit} kcal)")
    ax.set_title("Calories planned per day")
    ax.set_ylabel("kcal (one person)")
    ax.legend()
    fig.tight_layout()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return path


def plot_distribution(meals, path):
    plt = _load_pyplot()
    if plt is None:
        return None
    summary = compute_summary(meals)
    fig, (left, right) = plt.subplots(1, 2, figsize=(9, 4))
    for ax, data, title in (
        (left, summary["by_meal_type"], "Meals by type"),
        (right, summary["by_category"], "Meals by category"),
    ):
        names = list(data.keys())
        counts = [data[n] for n in names]
        ax.bar(names, counts, color="#5b8def")
        ax.set_title(title)
        ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return path


def plot_all(meals, folder, limit=DEFAULT_LIMIT):
    """Save both charts; returns a list of the files written (empty if no Matplotlib)."""
    folder = Path(folder)
    made = [
        plot_daily_calories(meals, folder / "calories_per_day.png", limit),
        plot_distribution(meals, folder / "meal_distribution.png"),
    ]
    return [p for p in made if p is not None]
