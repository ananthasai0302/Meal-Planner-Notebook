"""The terminal menu. All real work is done by the other modules."""

import os
import sys
from pathlib import Path

from . import exporter, importer, plotting
from .planner import (
    add_meal,
    build_grocery_list,
    build_week_plan,
    delete_meal,
    find_meal,
    pretty_quantity,
)
from .search import search_meals
from .storage import MealStore
from .summary import DEFAULT_LIMIT, compute_summary, get_warnings
from .validation import (
    CATEGORIES,
    DAYS,
    MEAL_TYPES,
    CancelledEntry,
    ask,
    ask_optional,
    clean_calories,
    clean_category,
    clean_day,
    clean_meal_type,
    clean_name,
    clean_servings,
    parse_ingredients,
)

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = BASE_DIR / "data" / "meals.json"
EXPORT_DIR = BASE_DIR / "exports"
PAGE_SIZE = 15

_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def paint(text, code):
    return f"\033[{code}m{text}\033[0m" if _COLOR else text


def green(t): return paint(t, "32")
def red(t): return paint(t, "31")
def yellow(t): return paint(t, "33")
def bold(t): return paint(t, "1")
def cyan(t): return paint(t, "36")


STATUS_PAINT = {"OK": green, "HIGH": red, "LOW": yellow, "EMPTY": lambda t: t}

MENU = [
    ("1", "Add a meal"),
    ("2", "View weekly plan"),
    ("3", "Grocery list"),
    ("4", "Search meals"),
    ("5", "List all meals"),
    ("6", "Delete a meal"),
    ("7", "Summary and warnings"),
    ("8", "Create charts"),
    ("9", "Export reports"),
    ("10", "Import meals from CSV"),
    ("0", "Save and exit"),
]


def print_banner():
    line = "=" * 46
    print(cyan(line))
    print(bold("        MEAL PLANNER NOTEBOOK"))
    print("   Plan your week, build your shopping list")
    print(cyan(line))


def meal_row(m):
    return f"{m.meal_id:<4} {m.day:<10} {m.meal_type:<10} {m.name[:28]:<28} {m.category:<15} {m.calories:>5} {m.servings:>3}"


def print_meals(meals, page_size=PAGE_SIZE):
    """Fixed-width table, paged so long lists stay readable."""
    if not meals:
        print("  (no meals to show)")
        return
    header = f"{'ID':<4} {'Day':<10} {'Type':<10} {'Name':<28} {'Category':<15} {'Kcal':>5} {'Srv':>3}"
    for start in range(0, len(meals), page_size):
        print(bold(header))
        print("-" * len(header))
        for meal in meals[start:start + page_size]:
            print(meal_row(meal))
        shown = min(start + page_size, len(meals))
        print(f"-- {shown} of {len(meals)} --")
        if shown < len(meals):
            try:
                if input("Enter for next page, q to stop: ").strip().lower() == "q":
                    return
            except EOFError:
                return


class App:
    def __init__(self, store=None, export_dir=EXPORT_DIR):
        self.store = store or MealStore(DATA_FILE)
        self.export_dir = Path(export_dir)
        self.meals = self.store.load()
        self.limit = DEFAULT_LIMIT

    # ---- helpers -------------------------------------------------
    def save(self):
        try:
            self.store.save(self.meals)
        except OSError as problem:
            print(red(f"  Could not save data: {problem}"))

    # ---- menu actions --------------------------------------------
    def add(self):
        print(bold("\nAdd a meal") + "  (type 'cancel' at any prompt to stop)")
        try:
            day = ask(f"Day ({', '.join(d[:3] for d in DAYS)})", clean_day)
            kind = ask(f"Meal type ({'/'.join(MEAL_TYPES)})", clean_meal_type)
            name = ask("Meal name", clean_name)
            category = ask(f"Category ({'/'.join(CATEGORIES)})", clean_category)
            calories = ask("Calories per serving (0-3000)", clean_calories)
            servings = ask("Servings (1-20)", clean_servings, default=1)
            print("Ingredients, per serving, as name:quantity:unit separated by commas")
            print("  e.g.  rice:100:g, onion:1:pcs, milk:200:ml")
            ingredients = ask("Ingredients", parse_ingredients)
        except CancelledEntry:
            print("  Cancelled, nothing was saved.")
            return
        meal = add_meal(self.meals, day, kind, name, category, calories, servings, ingredients)
        self.save()
        print(green(f"  Saved meal #{meal.meal_id}: {meal.name} ({meal.day} {meal.meal_type})"))

    def view_week(self):
        plan = build_week_plan(self.meals)
        summary = compute_summary(self.meals, self.limit)
        print(bold("\nWeekly plan"))
        for day in DAYS:
            status = summary["daily_status"][day]
            tag = STATUS_PAINT[status](f"[{status}]")
            print(f"\n{bold(day)}  {summary['daily_totals'][day]} kcal  {tag}")
            for kind in MEAL_TYPES:
                for meal in plan[day][kind]:
                    print(f"   {kind:<10} {meal.name} ({meal.calories} kcal x {meal.servings})")

    def grocery(self):
        day = ask_optional("Only for one day? Enter a day", clean_day)
        items = build_grocery_list(self.meals, day)
        title = f"Grocery list for {day}" if day else "Grocery list for the whole week"
        print(bold(f"\n{title}"))
        if not items:
            print("  (nothing to buy)")
            return
        for name, qty, unit in items:
            print(f"  [ ] {name:<24} {pretty_quantity(qty, unit)}")
        print(f"\n{len(items)} item(s). Quantities are per-serving amounts x servings.")

    def search(self):
        print(bold("\nSearch meals") + " (leave a filter blank to skip it)")
        keyword = input("Keyword (name or ingredient, blank to skip): ").strip() or None
        category = ask_optional("Category", clean_category)
        day = ask_optional("Day", clean_day)
        kind = ask_optional("Meal type", clean_meal_type)
        results = search_meals(self.meals, keyword, category, day, kind)
        print(f"\n{len(results)} match(es)")
        print_meals(results)

    def list_all(self):
        print(bold("\nAll meals"))
        print_meals(sorted(self.meals, key=lambda m: (DAYS.index(m.day), m.meal_id)))

    def delete(self):
        text = input("Meal ID to delete: ").strip()
        if not text.isdigit():
            print(red("  Please enter a numeric ID."))
            return
        meal = find_meal(self.meals, int(text))
        if meal is None:
            print(red(f"  No meal with ID {text}."))
            return
        sure = input(f"Delete '{meal.name}' on {meal.day}? (y/n): ").strip().lower()
        if sure == "y":
            delete_meal(self.meals, meal.meal_id)
            self.save()
            print(green("  Deleted."))
        else:
            print("  Kept.")

    def show_summary(self):
        s = compute_summary(self.meals, self.limit)
        print(bold("\nExecutive summary"))
        print(f"  Meals planned        : {s['total_meals']}")
        print(f"  Days with meals      : {s['planned_days']} / 7")
        print(f"  Total calories       : {s['total_calories']}")
        print(f"  Average per day      : {s['avg_per_planned_day']} kcal")
        print(f"  Average per meal     : {s['avg_per_meal']} kcal")
        if s["highest_day"]:
            print(f"  Heaviest day         : {s['highest_day']} ({s['daily_totals'][s['highest_day']]} kcal)")
            print(f"  Lightest day         : {s['lowest_day']} ({s['daily_totals'][s['lowest_day']]} kcal)")
        if s["top_ingredient"]:
            print(f"  Most used ingredient : {s['top_ingredient'][0]} (in {s['top_ingredient'][1]} meals)")
        print(bold("\n  Per day"))
        for day in DAYS:
            status = s["daily_status"][day]
            print(f"   {day:<10} {s['daily_totals'][day]:>5} kcal  {STATUS_PAINT[status](status)}")
        print(bold("\n  By meal type: ") + ", ".join(f"{k} {v}" for k, v in s["by_meal_type"].items()))
        print(bold("  By category : ") + ", ".join(f"{k} {v}" for k, v in s["by_category"].items()))
        warnings = get_warnings(self.meals, self.limit)
        print(bold("\n  Warnings"))
        if warnings:
            for w in warnings:
                print(yellow(f"   ! {w}"))
        else:
            print(green("   none"))

    def charts(self):
        if not self.meals:
            print("  Add some meals first.")
            return
        files = plotting.plot_all(self.meals, self.export_dir, self.limit)
        if not files:
            print(yellow("  Matplotlib is not installed. Run: pip install matplotlib"))
            return
        for f in files:
            print(green(f"  Saved {f}"))

    def export(self):
        if not self.meals:
            print("  Nothing to export yet.")
            return
        try:
            files = exporter.export_all(self.meals, self.export_dir, self.limit)
        except OSError as problem:
            print(red(f"  Export failed: {problem}"))
            return
        for f in files:
            print(green(f"  Wrote {f}"))

    def import_csv(self):
        path = input("Path to CSV file: ").strip().strip('"')
        if not path:
            print("  No file given.")
            return
        from .planner import next_id
        result = importer.import_csv(path, start_id=next_id(self.meals))
        self.meals.extend(result.meals)
        if result.meals:
            self.save()
        print(f"  Rows read: {result.rows_read}   imported: {result.ok}   rejected: {len(result.errors)}")
        if result.errors:
            log = importer.write_error_log(result.errors, self.export_dir / "import_errors.log")
            for line in result.errors[:5]:
                print(yellow(f"   ! {line}"))
            if len(result.errors) > 5:
                print(f"   ... and {len(result.errors) - 5} more")
            print(f"  Full error log: {log}")

    # ---- main loop -----------------------------------------------
    def run(self):
        print_banner()
        if self.store.notice:
            print(yellow(self.store.notice))
        actions = {
            "1": self.add, "2": self.view_week, "3": self.grocery, "4": self.search,
            "5": self.list_all, "6": self.delete, "7": self.show_summary,
            "8": self.charts, "9": self.export, "10": self.import_csv,
        }
        while True:
            print("\n" + bold("MAIN MENU"))
            for key, label in MENU:
                print(f"  {key:>2}. {label}")
            try:
                choice = input("Choose an option: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                choice = "0"
            if choice == "0":
                self.save()
                print("Saved. Goodbye!")
                return
            action = actions.get(choice)
            if action is None:
                print(red("  Please pick a number from the menu."))
                continue
            try:
                action()
            except KeyboardInterrupt:
                print("\n  Interrupted, back to the menu.")
            except EOFError:
                print("\n  Input closed.")
                self.save()
                return


def run():
    App().run()
