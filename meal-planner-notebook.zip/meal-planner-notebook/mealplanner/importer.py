"""Bulk import of meals from a CSV file with a row-by-row error log."""

import csv
from dataclasses import dataclass, field
from pathlib import Path

from .models import Meal
from .validation import (
    clean_calories,
    clean_category,
    clean_day,
    clean_meal_type,
    clean_name,
    clean_servings,
    parse_ingredients,
)

REQUIRED_COLUMNS = ["day", "meal_type", "name", "category", "calories", "servings", "ingredients"]


@dataclass
class ImportResult:
    meals: list = field(default_factory=list)
    errors: list = field(default_factory=list)   # strings like "Row 4: ..."
    rows_read: int = 0

    @property
    def ok(self):
        return len(self.meals)


def import_csv(path, start_id=1):
    """Read a CSV file and return an ImportResult.

    Bad rows are skipped and described in `errors`; good rows become Meal
    objects numbered from `start_id`.
    """
    result = ImportResult()
    path = Path(path)

    try:
        handle = open(path, "r", encoding="utf-8-sig", newline="")
    except OSError as problem:
        result.errors.append(f"File: cannot open {path} ({problem.strerror or problem})")
        return result

    with handle:
        try:
            reader = csv.DictReader(handle)
            header = [h.strip().lower() for h in (reader.fieldnames or [])]
            missing = [c for c in REQUIRED_COLUMNS if c not in header]
            if missing:
                result.errors.append(f"File: missing column(s): {', '.join(missing)}")
                return result

            next_id = start_id
            for row_number, raw_row in enumerate(reader, start=2):   # row 1 is the header
                result.rows_read += 1
                row = {(k or "").strip().lower(): (v or "") for k, v in raw_row.items()}
                try:
                    meal = Meal(
                        meal_id=next_id,
                        day=clean_day(row["day"]),
                        meal_type=clean_meal_type(row["meal_type"]),
                        name=clean_name(row["name"]),
                        category=clean_category(row["category"]),
                        calories=clean_calories(row["calories"]),
                        servings=clean_servings(row["servings"]),
                        ingredients=parse_ingredients(row["ingredients"]),
                    )
                except ValueError as problem:
                    result.errors.append(f"Row {row_number}: {problem}")
                    continue
                result.meals.append(meal)
                next_id += 1
        except (csv.Error, UnicodeDecodeError) as problem:
            result.errors.append(f"File: could not be parsed ({problem})")
    return result


def write_error_log(errors, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        if errors:
            handle.write("\n".join(errors) + "\n")
        else:
            handle.write("No errors.\n")
    return path
