"""Core logic: managing meals, the weekly plan and the grocery list."""

from collections import defaultdict

from .models import Meal
from .validation import DAYS, MEAL_TYPES

# Everything is converted to a base unit so that 500 g + 1 kg adds up properly.
_TO_BASE = {
    "g": ("g", 1),
    "kg": ("g", 1000),
    "ml": ("ml", 1),
    "l": ("ml", 1000),
    "pcs": ("pcs", 1),
    "tbsp": ("tbsp", 1),
    "tsp": ("tsp", 1),
    "cup": ("cup", 1),
}


def next_id(meals):
    return max((m.meal_id for m in meals), default=0) + 1


def add_meal(meals, day, meal_type, name, category, calories, servings, ingredients):
    meal = Meal(next_id(meals), day, meal_type, name, category, calories, servings, ingredients)
    meals.append(meal)
    return meal


def delete_meal(meals, meal_id):
    """Remove a meal by id. Returns True if something was removed."""
    for index, meal in enumerate(meals):
        if meal.meal_id == meal_id:
            del meals[index]
            return True
    return False


def find_meal(meals, meal_id):
    for meal in meals:
        if meal.meal_id == meal_id:
            return meal
    return None


def build_week_plan(meals):
    """Return {day: {meal_type: [Meal, ...]}} with every day and slot present."""
    plan = {day: {kind: [] for kind in MEAL_TYPES} for day in DAYS}
    for meal in meals:
        if meal.day in plan and meal.meal_type in plan[meal.day]:
            plan[meal.day][meal.meal_type].append(meal)
    return plan


def build_grocery_list(meals, day=None):
    """Add up every ingredient (quantity x servings) into one shopping list.

    Returns a sorted list of (name, quantity, unit) tuples in base units.
    If `day` is given only that day's meals are counted.
    """
    totals = defaultdict(float)
    for meal in meals:
        if day is not None and meal.day != day:
            continue
        for item in meal.ingredients:
            base_unit, factor = _TO_BASE.get(item.unit, (item.unit, 1))
            totals[(item.name.strip().lower(), base_unit)] += item.quantity * factor * meal.servings
    return [(name, round(qty, 2), unit) for (name, unit), qty in sorted(totals.items())]


def pretty_quantity(quantity, unit):
    """Make big amounts readable: 2500 g -> '2.5 kg'."""
    if unit == "g" and quantity >= 1000:
        return f"{quantity / 1000:g} kg"
    if unit == "ml" and quantity >= 1000:
        return f"{quantity / 1000:g} l"
    return f"{quantity:g} {unit}"
