"""Plain data classes for meals and ingredients."""

from dataclasses import dataclass, field


@dataclass
class Ingredient:
    name: str
    quantity: float   # amount needed for ONE serving
    unit: str

    def to_dict(self):
        return {"name": self.name, "quantity": self.quantity, "unit": self.unit}

    @classmethod
    def from_dict(cls, data):
        return cls(str(data["name"]), float(data["quantity"]), str(data["unit"]))

    def as_text(self):
        return f"{self.name}:{self.quantity:g}:{self.unit}"


@dataclass
class Meal:
    meal_id: int
    day: str
    meal_type: str
    name: str
    category: str
    calories: int          # calories in one serving (one person)
    servings: int          # how many portions we are cooking
    ingredients: list = field(default_factory=list)

    def to_dict(self):
        return {
            "meal_id": self.meal_id,
            "day": self.day,
            "meal_type": self.meal_type,
            "name": self.name,
            "category": self.category,
            "calories": self.calories,
            "servings": self.servings,
            "ingredients": [i.to_dict() for i in self.ingredients],
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            meal_id=int(data["meal_id"]),
            day=str(data["day"]),
            meal_type=str(data["meal_type"]),
            name=str(data["name"]),
            category=str(data["category"]),
            calories=int(data["calories"]),
            servings=int(data["servings"]),
            ingredients=[Ingredient.from_dict(i) for i in data.get("ingredients", [])],
        )

    def ingredients_text(self):
        """Ingredients in the compact CSV form: name:qty:unit;name:qty:unit"""
        return ";".join(i.as_text() for i in self.ingredients)
