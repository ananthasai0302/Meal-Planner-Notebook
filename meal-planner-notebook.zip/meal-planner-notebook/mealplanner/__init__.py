"""Meal Planner Notebook - plan a week of meals and build a shopping list."""

__version__ = "1.0.0"
