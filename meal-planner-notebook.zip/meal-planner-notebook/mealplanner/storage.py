"""Saving and loading meals as JSON, tolerating missing or damaged files."""

import json
import os
import shutil
import tempfile
from pathlib import Path

from .models import Meal


class MealStore:
    def __init__(self, path):
        self.path = Path(path)
        self.notice = ""          # message shown to the user after load()
        self.skipped_records = 0

    def load(self):
        self.notice = ""
        self.skipped_records = 0

        if not self.path.exists():
            self.notice = f"No data file found, starting fresh ({self.path})."
            return []

        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                raw = json.load(handle)
        except (json.JSONDecodeError, UnicodeDecodeError):
            self._back_up_corrupt_file()
            return []
        except OSError as problem:
            self.notice = f"Could not read {self.path}: {problem}. Starting empty."
            return []

        if not isinstance(raw, dict) or not isinstance(raw.get("meals"), list):
            self._back_up_corrupt_file()
            return []

        meals = []
        seen_ids = set()
        for record in raw["meals"]:
            try:
                meal = Meal.from_dict(record)
            except (KeyError, TypeError, ValueError, AttributeError):
                self.skipped_records += 1
                continue
            if meal.meal_id in seen_ids:
                self.skipped_records += 1
                continue
            seen_ids.add(meal.meal_id)
            meals.append(meal)

        if self.skipped_records:
            self.notice = f"Skipped {self.skipped_records} unreadable record(s) while loading."
        return meals

    def save(self, meals):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"version": 1, "meals": [m.to_dict() for m in meals]}
        # write to a temp file first so a crash cannot leave half a file behind
        fd, temp_name = tempfile.mkstemp(dir=self.path.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2)
            os.replace(temp_name, self.path)
        except OSError:
            if os.path.exists(temp_name):
                os.remove(temp_name)
            raise

    def _back_up_corrupt_file(self):
        backup = self.path.with_suffix(self.path.suffix + ".corrupt")
        try:
            shutil.copy(self.path, backup)
            self.notice = f"Data file was damaged. A copy was kept as {backup.name}; starting fresh."
        except OSError:
            self.notice = "Data file was damaged; starting fresh."
