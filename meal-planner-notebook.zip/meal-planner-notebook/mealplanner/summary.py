"""Totals, averages, daily status flags and warnings."""

from collections import Counter

from .validation import DAYS

DEFAULT_LIMIT = 2500     # calories per day we treat as "too much"
LOW_LIMIT = 1200         # below this a planned day looks too light
ANOMALY_CALORIES = 1500  # a single serving above this gets flagged


def daily_totals(meals):
    """Calories for one person per day (each meal counted once)."""
    totals = {day: 0 for day in DAYS}
    for meal in meals:
        if meal.day in totals:
            totals[meal.day] += meal.calories
    return totals


def day_status(total, meal_count, limit=DEFAULT_LIMIT):
    if meal_count == 0:
        return "EMPTY"
    if total > limit:
        return "HIGH"
    if total < LOW_LIMIT:
        return "LOW"
    return "OK"


def compute_summary(meals, limit=DEFAULT_LIMIT):
    totals = daily_totals(meals)
    counts = {day: 0 for day in DAYS}
    for meal in meals:
        if meal.day in counts:
            counts[meal.day] += 1

    planned = [d for d in DAYS if counts[d] > 0]
    total_calories = sum(totals.values())
    summary = {
        "total_meals": len(meals),
        "total_calories": total_calories,
        "planned_days": len(planned),
        "avg_per_planned_day": round(total_calories / len(planned), 1) if planned else 0.0,
        "avg_per_meal": round(total_calories / len(meals), 1) if meals else 0.0,
        "daily_totals": totals,
        "daily_status": {d: day_status(totals[d], counts[d], limit) for d in DAYS},
        "by_meal_type": dict(Counter(m.meal_type for m in meals)),
        "by_category": dict(Counter(m.category for m in meals)),
        "empty_days": [d for d in DAYS if counts[d] == 0],
        "highest_day": None,
        "lowest_day": None,
        "top_ingredient": None,
    }

    if planned:
        summary["highest_day"] = max(planned, key=lambda d: totals[d])
        summary["lowest_day"] = min(planned, key=lambda d: totals[d])

    ingredient_use = Counter(i.name for m in meals for i in m.ingredients)
    if ingredient_use:
        summary["top_ingredient"] = ingredient_use.most_common(1)[0]
    return summary


def get_warnings(meals, limit=DEFAULT_LIMIT):
    """Plain-text warnings for the console and reports."""
    messages = []
    totals = daily_totals(meals)
    counts = Counter(m.day for m in meals)

    for day in DAYS:
        status = day_status(totals[day], counts[day], limit)
        if status == "EMPTY":
            messages.append(f"{day}: nothing planned yet.")
        elif status == "HIGH":
            messages.append(f"{day}: {totals[day]} kcal is over the {limit} kcal limit.")
        elif status == "LOW":
            messages.append(f"{day}: only {totals[day]} kcal planned (under {LOW_LIMIT}).")

    for meal in meals:
        if meal.calories > ANOMALY_CALORIES:
            messages.append(
                f"Meal #{meal.meal_id} '{meal.name}' has {meal.calories} kcal per serving - please double check."
            )
    return messages
