"""Keyword and filter based lookups."""


def search_meals(meals, keyword=None, category=None, day=None, meal_type=None):
    """Return meals matching ALL of the given filters.

    The keyword is checked against the meal name and its ingredient names.
    """
    keyword = keyword.strip().lower() if keyword else None
    found = []
    for meal in meals:
        if category and meal.category != category:
            continue
        if day and meal.day != day:
            continue
        if meal_type and meal.meal_type != meal_type:
            continue
        if keyword:
            in_name = keyword in meal.name.lower()
            in_ingredients = any(keyword in i.name.lower() for i in meal.ingredients)
            if not (in_name or in_ingredients):
                continue
        found.append(meal)
    return found
