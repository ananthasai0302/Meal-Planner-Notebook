"""Start the Meal Planner Notebook:  python main.py"""

from mealplanner.ui import run

if __name__ == "__main__":
    run()
