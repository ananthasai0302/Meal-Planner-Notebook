# Meal Planner Notebook

A menu-driven Python app for planning a week of meals and turning the plan into
one combined shopping list. Built for the SmartCommunity Hack (Project #35,
Health & Wellbeing).

![Calories per day](docs/sample_chart.png)

## What it does

| Feature | Where |
|---|---|
| Menu-driven terminal interface with ANSI colours | `mealplanner/ui.py` |
| Input validation (ranges, types, blanks, units) with retry loops | `mealplanner/validation.py` |
| Weekly plan + grocery list (merges kg/g and l/ml, multiplies by servings) | `mealplanner/planner.py` |
| JSON persistence, survives restarts, handles missing/corrupt files | `mealplanner/storage.py` |
| Search by keyword (name or ingredient), category, day, meal type | `mealplanner/search.py` |
| Summary: totals, averages, daily status (OK / LOW / HIGH / EMPTY), trends | `mealplanner/summary.py` |
| Matplotlib charts (calories per day, distribution) | `mealplanner/plotting.py` |
| Export to Markdown, text audit log and CSV | `mealplanner/exporter.py` |
| Warning flags for heavy days, empty days, suspicious meals | `mealplanner/summary.py` |
| Bulk CSV import with a row-by-row error log | `mealplanner/importer.py` |

## Setup

Requires Python 3.10 or newer.

```bash
python -m venv .venv
# Windows:  .venv\Scripts\activate
# Mac/Linux: source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

Matplotlib is the only dependency. If it is missing the app still runs and
just tells you charts are unavailable.

The repo ships with 40 sample meals in `data/meals.json`, so every menu option
has something to show straight away.

## How to use

Pick a number from the main menu. At any prompt while adding a meal you can type
`cancel` to stop. Days accept short forms (`mon`, `fri`).

Ingredients are typed as `name:quantity:unit`, separated by commas, and the
quantity is **per serving**:

```
rice:100:g, onion:1:pcs, milk:200:ml
```

Allowed units: `g, kg, ml, l, pcs, tbsp, tsp, cup`.

Calories are per serving (one person). The daily calorie status uses a 2500 kcal
upper limit and a 1200 kcal lower limit.

## Demo script (about 3 minutes)

1. `python main.py` - show the welcome screen.
2. Option **1**: add a meal and deliberately type a wrong day, `abc` for calories,
   `5000`, and a bad ingredient. Show each error being caught.
3. Option **7**: show the summary. Wednesday and Saturday are flagged HIGH.
4. Option **3**: show the grocery list (big amounts show as kg / l).
5. Option **8** and **9**: create charts and export reports into `exports/`.
6. Option **0**, then run `python main.py` again - the new meal is still there.
7. Option **10** with `sample_data/legacy_with_errors.csv` to show the import
   error log (`exports/import_errors.log`).

## Running the tests

```bash
python -m unittest discover -s tests -t . -v
```

85 tests cover validation boundaries, grocery maths, persistence, corrupt files,
search, summaries, import errors, exports, charts and scripted menu sessions.

## Project layout

```
main.py                 entry point
mealplanner/            application code
tests/                  unit and menu tests
data/meals.json         working data file
sample_data/            40-row sample (CSV + JSON) and a CSV with deliberate errors
docs/                   screenshots
exports/                reports and charts are written here
```

## Design notes

- The `clean_*` functions raise `ValueError` and are shared by the prompts and
  the CSV importer, so both paths apply identical rules.
- Saving writes to a temporary file and then replaces the real one, so a crash
  mid-save cannot damage the data.
- A damaged data file is copied to `meals.json.corrupt` and the app starts fresh
  instead of crashing.
