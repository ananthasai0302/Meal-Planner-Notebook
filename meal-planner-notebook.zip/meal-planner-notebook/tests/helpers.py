"""Small builders shared by the tests."""

from mealplanner.models import Ingredient, Meal


def make_meal(meal_id=1, day="Monday", kind="Lunch", name="Test Meal", category="Vegetarian",
              calories=500, servings=1, ingredients=None):
    if ingredients is None:
        ingredients = [Ingredient("rice", 100, "g")]
    return Meal(meal_id, day, kind, name, category, calories, servings, ingredients)
