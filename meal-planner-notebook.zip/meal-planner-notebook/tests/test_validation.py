import unittest
from unittest.mock import patch

from mealplanner import validation as v


class CleanerTests(unittest.TestCase):
    def test_day_accepts_full_short_and_mixed_case(self):
        self.assertEqual(v.clean_day("Monday"), "Monday")
        self.assertEqual(v.clean_day("  tue "), "Tuesday")
        self.assertEqual(v.clean_day("SATURDAY"), "Saturday")

    def test_day_rejects_garbage_and_blank(self):
        for bad in ["", "   ", "Funday", "mo", "1"]:
            with self.assertRaises(ValueError):
                v.clean_day(bad)

    def test_meal_type_and_category(self):
        self.assertEqual(v.clean_meal_type("snack"), "Snack")
        self.assertEqual(v.clean_category("vegan"), "Vegan")
        self.assertEqual(v.clean_category("non-vegetarian"), "Non-Vegetarian")
        with self.assertRaises(ValueError):
            v.clean_meal_type("brunch")
        with self.assertRaises(ValueError):
            v.clean_category("")

    def test_name_rules(self):
        self.assertEqual(v.clean_name("  Dal   Tadka "), "Dal Tadka")
        for bad in ["", "a", "x" * 51, "<script>", "!!"]:
            with self.assertRaises(ValueError):
                v.clean_name(bad)

    def test_calorie_boundaries(self):
        self.assertEqual(v.clean_calories("0"), 0)
        self.assertEqual(v.clean_calories("3000"), 3000)
        for bad in ["-1", "3001", "abc", "", "12.5", " "]:
            with self.assertRaises(ValueError):
                v.clean_calories(bad)

    def test_servings_boundaries(self):
        self.assertEqual(v.clean_servings("1"), 1)
        self.assertEqual(v.clean_servings("20"), 20)
        for bad in ["0", "21", "two", ""]:
            with self.assertRaises(ValueError):
                v.clean_servings(bad)


class IngredientParsingTests(unittest.TestCase):
    def test_valid_list(self):
        items = v.parse_ingredients("Rice:100:g, onion:1:PCS; milk:0.5:l")
        self.assertEqual([i.name for i in items], ["rice", "onion", "milk"])
        self.assertEqual(items[1].unit, "pcs")
        self.assertEqual(items[2].quantity, 0.5)

    def test_invalid_inputs(self):
        bad_inputs = [
            "", "   ", ",,;", "rice", "rice:100", "rice:abc:g", "rice:0:g",
            "rice:-5:g", "rice:100:bags", "r:100:g", "rice:nan:g", "rice:1e9:g",
        ]
        for bad in bad_inputs:
            with self.assertRaises(ValueError, msg=bad):
                v.parse_ingredients(bad)

    def test_too_many_ingredients(self):
        text = ";".join(f"item{i}:1:g" for i in range(21))
        with self.assertRaises(ValueError):
            v.parse_ingredients(text)


class PromptLoopTests(unittest.TestCase):
    def test_ask_retries_until_valid(self):
        with patch("builtins.input", side_effect=["abc", "-5", "99999", "450"]), patch("builtins.print"):
            self.assertEqual(v.ask("Calories", v.clean_calories), 450)

    def test_ask_uses_default_on_blank(self):
        with patch("builtins.input", side_effect=[""]):
            self.assertEqual(v.ask("Servings", v.clean_servings, default=1), 1)

    def test_cancel_raises(self):
        with patch("builtins.input", side_effect=["cancel"]):
            with self.assertRaises(v.CancelledEntry):
                v.ask("Day", v.clean_day)

    def test_ask_optional_blank_is_none(self):
        with patch("builtins.input", side_effect=[""]):
            self.assertIsNone(v.ask_optional("Day", v.clean_day))

    def test_ask_optional_retries_on_bad_value(self):
        with patch("builtins.input", side_effect=["xyz", "fri"]), patch("builtins.print"):
            self.assertEqual(v.ask_optional("Day", v.clean_day), "Friday")


if __name__ == "__main__":
    unittest.main()
