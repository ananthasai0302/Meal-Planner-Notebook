import unittest

from mealplanner.models import Ingredient
from mealplanner.search import search_meals
from tests.helpers import make_meal


class SearchTests(unittest.TestCase):
    def setUp(self):
        self.meals = [
            make_meal(1, day="Monday", kind="Lunch", name="Paneer Wrap", category="Vegetarian",
                      ingredients=[Ingredient("paneer", 100, "g")]),
            make_meal(2, day="Monday", kind="Dinner", name="Chicken Curry", category="Non-Vegetarian",
                      ingredients=[Ingredient("chicken", 150, "g"), Ingredient("onion", 1, "pcs")]),
            make_meal(3, day="Friday", kind="Dinner", name="Veg Pulao", category="Vegan",
                      ingredients=[Ingredient("rice", 100, "g"), Ingredient("onion", 1, "pcs")]),
        ]

    def ids(self, **kwargs):
        return [m.meal_id for m in search_meals(self.meals, **kwargs)]

    def test_no_filters_returns_everything(self):
        self.assertEqual(self.ids(), [1, 2, 3])

    def test_keyword_matches_name_case_insensitive(self):
        self.assertEqual(self.ids(keyword="PANEER"), [1])

    def test_keyword_matches_ingredient(self):
        self.assertEqual(self.ids(keyword="onion"), [2, 3])

    def test_category_filter(self):
        self.assertEqual(self.ids(category="Vegan"), [3])

    def test_day_and_type_filters_combine(self):
        self.assertEqual(self.ids(day="Monday", meal_type="Dinner"), [2])

    def test_combined_keyword_and_category(self):
        self.assertEqual(self.ids(keyword="onion", category="Vegan"), [3])

    def test_no_match_returns_empty(self):
        self.assertEqual(self.ids(keyword="pizza"), [])

    def test_blank_keyword_is_ignored(self):
        self.assertEqual(self.ids(keyword="   "), [1, 2, 3])


if __name__ == "__main__":
    unittest.main()
