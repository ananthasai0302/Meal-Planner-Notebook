import unittest

from mealplanner import planner
from mealplanner.models import Ingredient
from tests.helpers import make_meal


class MealManagementTests(unittest.TestCase):
    def test_add_meal_assigns_incrementing_ids(self):
        meals = []
        first = planner.add_meal(meals, "Monday", "Lunch", "A1", "Vegan", 100, 1, [Ingredient("x1", 1, "g")])
        second = planner.add_meal(meals, "Monday", "Dinner", "B2", "Vegan", 100, 1, [Ingredient("x1", 1, "g")])
        self.assertEqual((first.meal_id, second.meal_id), (1, 2))
        self.assertEqual(len(meals), 2)

    def test_next_id_after_deleting_does_not_reuse(self):
        meals = [make_meal(1), make_meal(5)]
        self.assertEqual(planner.next_id(meals), 6)
        planner.delete_meal(meals, 5)
        self.assertEqual(planner.next_id(meals), 2)

    def test_delete_and_find(self):
        meals = [make_meal(1), make_meal(2)]
        self.assertTrue(planner.delete_meal(meals, 1))
        self.assertFalse(planner.delete_meal(meals, 99))
        self.assertIsNone(planner.find_meal(meals, 1))
        self.assertEqual(planner.find_meal(meals, 2).meal_id, 2)


class WeekPlanTests(unittest.TestCase):
    def test_plan_has_every_day_and_slot(self):
        plan = planner.build_week_plan([])
        self.assertEqual(len(plan), 7)
        self.assertEqual(set(plan["Monday"].keys()), {"Breakfast", "Lunch", "Dinner", "Snack"})

    def test_meals_land_in_right_slot(self):
        meal = make_meal(1, day="Friday", kind="Dinner")
        plan = planner.build_week_plan([meal])
        self.assertEqual(plan["Friday"]["Dinner"], [meal])
        self.assertEqual(plan["Friday"]["Lunch"], [])


class GroceryTests(unittest.TestCase):
    def test_servings_multiply_quantities(self):
        meal = make_meal(servings=3, ingredients=[Ingredient("rice", 100, "g")])
        self.assertEqual(planner.build_grocery_list([meal]), [("rice", 300.0, "g")])

    def test_same_ingredient_is_combined_across_meals(self):
        a = make_meal(1, ingredients=[Ingredient("rice", 100, "g")], servings=2)
        b = make_meal(2, day="Tuesday", ingredients=[Ingredient("Rice", 50, "g")], servings=1)
        self.assertEqual(planner.build_grocery_list([a, b]), [("rice", 250.0, "g")])

    def test_kg_and_g_are_merged(self):
        a = make_meal(1, ingredients=[Ingredient("flour", 1, "kg")])
        b = make_meal(2, ingredients=[Ingredient("flour", 500, "g")])
        self.assertEqual(planner.build_grocery_list([a, b]), [("flour", 1500.0, "g")])

    def test_litres_and_ml_are_merged(self):
        a = make_meal(1, ingredients=[Ingredient("milk", 0.5, "l")])
        b = make_meal(2, ingredients=[Ingredient("milk", 250, "ml")])
        self.assertEqual(planner.build_grocery_list([a, b]), [("milk", 750.0, "ml")])

    def test_different_units_stay_separate(self):
        meal = make_meal(ingredients=[Ingredient("egg", 2, "pcs"), Ingredient("egg", 50, "g")])
        self.assertEqual(len(planner.build_grocery_list([meal])), 2)

    def test_day_filter(self):
        a = make_meal(1, day="Monday", ingredients=[Ingredient("rice", 100, "g")])
        b = make_meal(2, day="Tuesday", ingredients=[Ingredient("dal", 80, "g")])
        self.assertEqual(planner.build_grocery_list([a, b], day="Tuesday"), [("dal", 80.0, "g")])

    def test_empty_plan_gives_empty_list(self):
        self.assertEqual(planner.build_grocery_list([]), [])

    def test_result_is_sorted(self):
        meal = make_meal(ingredients=[Ingredient("zucchini", 1, "pcs"), Ingredient("apple", 1, "pcs")])
        names = [row[0] for row in planner.build_grocery_list([meal])]
        self.assertEqual(names, ["apple", "zucchini"])

    def test_pretty_quantity(self):
        self.assertEqual(planner.pretty_quantity(2500, "g"), "2.5 kg")
        self.assertEqual(planner.pretty_quantity(999, "g"), "999 g")
        self.assertEqual(planner.pretty_quantity(1500, "ml"), "1.5 l")
        self.assertEqual(planner.pretty_quantity(3, "pcs"), "3 pcs")


if __name__ == "__main__":
    unittest.main()
