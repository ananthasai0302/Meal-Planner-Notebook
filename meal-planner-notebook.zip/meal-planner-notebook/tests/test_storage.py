import json
import tempfile
import unittest
from pathlib import Path

from mealplanner.storage import MealStore
from tests.helpers import make_meal


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "data" / "meals.json"
        self.store = MealStore(self.path)

    def tearDown(self):
        self.tmp.cleanup()

    def test_missing_file_gives_empty_list(self):
        self.assertEqual(self.store.load(), [])
        self.assertIn("starting fresh", self.store.notice)

    def test_round_trip_survives_restart(self):
        meals = [make_meal(1, name="Dal"), make_meal(2, name="Rice Bowl", servings=4)]
        self.store.save(meals)
        reloaded = MealStore(self.path).load()     # a brand new store object = a restart
        self.assertEqual(reloaded, meals)

    def test_corrupt_json_is_backed_up_and_ignored(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text("{ this is not json", encoding="utf-8")
        self.assertEqual(self.store.load(), [])
        self.assertTrue(self.path.with_suffix(".json.corrupt").exists())
        self.assertIn("damaged", self.store.notice)

    def test_wrong_shape_is_treated_as_corrupt(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps([1, 2, 3]), encoding="utf-8")
        self.assertEqual(self.store.load(), [])
        self.assertIn("damaged", self.store.notice)

    def test_empty_file_is_handled(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text("", encoding="utf-8")
        self.assertEqual(self.store.load(), [])

    def test_bad_records_are_skipped_but_good_ones_kept(self):
        good = make_meal(1).to_dict()
        payload = {"meals": [good, {"meal_id": 2}, "junk", dict(good, meal_id=1)]}
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps(payload), encoding="utf-8")
        loaded = self.store.load()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(self.store.skipped_records, 3)

    def test_save_leaves_no_temp_files(self):
        self.store.save([make_meal(1)])
        leftovers = [p for p in self.path.parent.iterdir() if p.suffix == ".tmp"]
        self.assertEqual(leftovers, [])

    def test_shipped_sample_json_loads(self):
        sample = Path(__file__).resolve().parent.parent / "sample_data" / "sample_meals.json"
        store = MealStore(sample)
        meals = store.load()
        self.assertEqual(len(meals), 40)
        self.assertEqual(store.skipped_records, 0)


if __name__ == "__main__":
    unittest.main()
