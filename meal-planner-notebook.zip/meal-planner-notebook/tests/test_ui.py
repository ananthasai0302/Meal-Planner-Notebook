"""End-to-end style tests that drive the menu with scripted input."""

import contextlib
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from mealplanner.storage import MealStore
from mealplanner.ui import App

ROOT = Path(__file__).resolve().parent.parent


def run_app(app, answers):
    out = io.StringIO()
    with patch("builtins.input", side_effect=answers), contextlib.redirect_stdout(out):
        app.run()
    return out.getvalue()


class MenuTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name) / "meals.json"
        self.exports = Path(self.tmp.name) / "exports"

    def tearDown(self):
        self.tmp.cleanup()

    def new_app(self):
        return App(MealStore(self.data), export_dir=self.exports)

    def test_exit_immediately(self):
        text = run_app(self.new_app(), ["0"])
        self.assertIn("MEAL PLANNER NOTEBOOK", text)
        self.assertIn("Goodbye", text)

    def test_invalid_menu_choice_is_rejected(self):
        text = run_app(self.new_app(), ["abc", "99", "", "0"])
        self.assertEqual(text.count("Please pick a number"), 3)

    def test_add_meal_with_bad_inputs_then_persist(self):
        answers = [
            "1",
            "Funday", "mon",                 # bad day, then good
            "lunch",
            "x", "Dal Rice",                 # too short name, then good
            "vegan",
            "abc", "5000", "550",            # not a number, too big, good
            "0", "2",                        # servings 0 bad, 2 good
            "rice", "dal:50:g, rice:80:g",   # bad ingredients, then good
            "0",
        ]
        text = run_app(self.new_app(), answers)
        self.assertIn("Saved meal #1", text)
        self.assertGreaterEqual(text.count("  ! "), 5)

        # "restart" the program: a fresh App reading the same file
        again = self.new_app()
        self.assertEqual(len(again.meals), 1)
        self.assertEqual(again.meals[0].calories, 550)
        self.assertEqual(again.meals[0].servings, 2)

    def test_cancel_during_add_saves_nothing(self):
        text = run_app(self.new_app(), ["1", "mon", "cancel", "0"])
        self.assertIn("Cancelled", text)
        self.assertEqual(len(self.new_app().meals), 0)

    def test_summary_on_sample_data_shows_warnings(self):
        self.data.write_text((ROOT / "sample_data" / "sample_meals.json").read_text(encoding="utf-8"), encoding="utf-8")
        text = run_app(self.new_app(), ["7", "0"])
        self.assertIn("Executive summary", text)
        self.assertIn("Meals planned        : 40", text)
        self.assertIn("over the 2500", text)

    def test_search_flow(self):
        self.data.write_text((ROOT / "sample_data" / "sample_meals.json").read_text(encoding="utf-8"), encoding="utf-8")
        text = run_app(self.new_app(), ["4", "paneer", "", "", "", "0"])
        self.assertIn("1 match(es)", text)
        self.assertIn("Paneer Wrap", text)

    def test_grocery_for_one_day(self):
        self.data.write_text((ROOT / "sample_data" / "sample_meals.json").read_text(encoding="utf-8"), encoding="utf-8")
        text = run_app(self.new_app(), ["3", "sat", "0"])
        self.assertIn("Grocery list for Saturday", text)
        self.assertIn("3 kg", text)     # party platter: 150 g x 20 chicken

    def test_delete_flow(self):
        self.data.write_text((ROOT / "sample_data" / "sample_meals.json").read_text(encoding="utf-8"), encoding="utf-8")
        app = self.new_app()
        run_app(app, ["6", "abc", "6", "999", "6", "1", "n", "6", "1", "y", "0"])
        self.assertEqual(len(app.meals), 39)
        self.assertEqual(len(self.new_app().meals), 39)

    def test_pagination_stops_on_q(self):
        self.data.write_text((ROOT / "sample_data" / "sample_meals.json").read_text(encoding="utf-8"), encoding="utf-8")
        text = run_app(self.new_app(), ["5", "q", "0"])
        self.assertIn("15 of 40", text)
        self.assertNotIn("30 of 40", text)

    def test_import_flow_logs_errors(self):
        path = str(ROOT / "sample_data" / "legacy_with_errors.csv")
        text = run_app(self.new_app(), ["10", path, "0"])
        self.assertIn("imported: 2", text)
        self.assertIn("rejected: 7", text)
        self.assertTrue((self.exports / "import_errors.log").exists())

    def test_export_creates_files(self):
        self.data.write_text((ROOT / "sample_data" / "sample_meals.json").read_text(encoding="utf-8"), encoding="utf-8")
        run_app(self.new_app(), ["9", "0"])
        self.assertEqual(len(list(self.exports.glob("meal_*"))), 3)

    def test_eof_does_not_crash(self):
        out = io.StringIO()
        with patch("builtins.input", side_effect=EOFError), contextlib.redirect_stdout(out):
            self.new_app().run()
        self.assertIn("Goodbye", out.getvalue())

    def test_corrupt_file_on_start_shows_notice(self):
        self.data.write_text("not json at all", encoding="utf-8")
        text = run_app(self.new_app(), ["0"])
        self.assertIn("damaged", text)


if __name__ == "__main__":
    unittest.main()
