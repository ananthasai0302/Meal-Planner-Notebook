import unittest

from mealplanner import summary
from mealplanner.models import Ingredient
from tests.helpers import make_meal


class SummaryTests(unittest.TestCase):
    def test_empty_plan(self):
        s = summary.compute_summary([])
        self.assertEqual(s["total_meals"], 0)
        self.assertEqual(s["avg_per_planned_day"], 0.0)
        self.assertEqual(s["avg_per_meal"], 0.0)
        self.assertEqual(len(s["empty_days"]), 7)
        self.assertIsNone(s["highest_day"])
        self.assertIsNone(s["top_ingredient"])

    def test_totals_and_averages(self):
        meals = [
            make_meal(1, day="Monday", calories=600),
            make_meal(2, day="Monday", calories=400),
            make_meal(3, day="Tuesday", calories=1500),
        ]
        s = summary.compute_summary(meals)
        self.assertEqual(s["total_calories"], 2500)
        self.assertEqual(s["planned_days"], 2)
        self.assertEqual(s["avg_per_planned_day"], 1250.0)
        self.assertEqual(s["avg_per_meal"], 833.3)
        self.assertEqual(s["highest_day"], "Tuesday")
        self.assertEqual(s["lowest_day"], "Monday")

    def test_servings_do_not_inflate_calories(self):
        s = summary.compute_summary([make_meal(1, calories=500, servings=10)])
        self.assertEqual(s["total_calories"], 500)

    def test_status_thresholds(self):
        self.assertEqual(summary.day_status(0, 0), "EMPTY")
        self.assertEqual(summary.day_status(1199, 1), "LOW")
        self.assertEqual(summary.day_status(1200, 1), "OK")
        self.assertEqual(summary.day_status(2500, 1), "OK")
        self.assertEqual(summary.day_status(2501, 1), "HIGH")

    def test_custom_limit(self):
        self.assertEqual(summary.day_status(2000, 3, limit=1800), "HIGH")

    def test_category_and_type_counts(self):
        meals = [make_meal(1, category="Vegan", kind="Lunch"), make_meal(2, category="Vegan", kind="Snack")]
        s = summary.compute_summary(meals)
        self.assertEqual(s["by_category"], {"Vegan": 2})
        self.assertEqual(s["by_meal_type"], {"Lunch": 1, "Snack": 1})

    def test_top_ingredient(self):
        onion = Ingredient("onion", 1, "pcs")
        meals = [make_meal(1, ingredients=[onion]), make_meal(2, ingredients=[onion, Ingredient("rice", 1, "g")])]
        self.assertEqual(summary.compute_summary(meals)["top_ingredient"], ("onion", 2))


class WarningTests(unittest.TestCase):
    def test_empty_days_are_reported(self):
        warnings = summary.get_warnings([make_meal(1, day="Monday", calories=1500)])
        self.assertEqual(sum("nothing planned" in w for w in warnings), 6)

    def test_high_and_low_days(self):
        meals = [
            make_meal(1, day="Monday", calories=1400),
            make_meal(2, day="Monday", calories=1400),
            make_meal(3, day="Tuesday", calories=300),
        ]
        text = " | ".join(summary.get_warnings(meals))
        self.assertIn("Monday: 2800 kcal is over", text)
        self.assertIn("Tuesday: only 300 kcal", text)

    def test_anomalous_meal_is_flagged(self):
        warnings = summary.get_warnings([make_meal(7, name="Giant", calories=3000)])
        self.assertTrue(any("#7" in w and "double check" in w for w in warnings))

    def test_normal_week_has_no_anomaly_warning(self):
        warnings = summary.get_warnings([make_meal(1, calories=800)])
        self.assertFalse(any("double check" in w for w in warnings))


if __name__ == "__main__":
    unittest.main()
