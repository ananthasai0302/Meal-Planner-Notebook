import tempfile
import unittest
from pathlib import Path

from mealplanner import exporter, importer, plotting
from mealplanner.storage import MealStore
from tests.helpers import make_meal

ROOT = Path(__file__).resolve().parent.parent
HEADER = "day,meal_type,name,category,calories,servings,ingredients\n"


class ImporterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, text, name="in.csv"):
        path = self.dir / name
        path.write_text(text, encoding="utf-8")
        return path

    def test_clean_file(self):
        path = self.write(HEADER + "Monday,Lunch,Dal Rice,Vegan,500,2,dal:50:g;rice:80:g\n")
        result = importer.import_csv(path, start_id=10)
        self.assertEqual(result.ok, 1)
        self.assertEqual(result.errors, [])
        self.assertEqual(result.meals[0].meal_id, 10)

    def test_bad_rows_are_logged_with_row_numbers(self):
        result = importer.import_csv(ROOT / "sample_data" / "legacy_with_errors.csv")
        self.assertEqual(result.rows_read, 9)
        self.assertEqual(result.ok, 2)
        self.assertEqual(len(result.errors), 7)
        self.assertTrue(result.errors[0].startswith("Row 3:"))   # Funday is on file row 3

    def test_missing_file(self):
        result = importer.import_csv(self.dir / "nope.csv")
        self.assertEqual(result.ok, 0)
        self.assertTrue(result.errors[0].startswith("File:"))

    def test_missing_columns(self):
        path = self.write("day,name\nMonday,Soup\n")
        result = importer.import_csv(path)
        self.assertIn("missing column", result.errors[0])

    def test_empty_file(self):
        result = importer.import_csv(self.write(""))
        self.assertEqual(result.ok, 0)
        self.assertEqual(len(result.errors), 1)

    def test_header_only(self):
        result = importer.import_csv(self.write(HEADER))
        self.assertEqual((result.rows_read, result.ok, result.errors), (0, 0, []))

    def test_bom_and_header_case_are_tolerated(self):
        path = self.dir / "bom.csv"
        path.write_bytes(b"\xef\xbb\xbf" + b"Day,Meal_Type,Name,Category,Calories,Servings,Ingredients\n"
                         b"Monday,Lunch,Dal Rice,Vegan,500,2,dal:50:g\n")
        self.assertEqual(importer.import_csv(path).ok, 1)

    def test_ids_continue_after_bad_rows(self):
        text = HEADER + "Monday,Lunch,Good One,Vegan,500,1,rice:50:g\nBad,Lunch,X,Vegan,5,1,rice:5:g\nTuesday,Lunch,Good Two,Vegan,500,1,rice:50:g\n"
        ids = [m.meal_id for m in importer.import_csv(self.write(text), start_id=1).meals]
        self.assertEqual(ids, [1, 2])

    def test_sample_csv_imports_cleanly(self):
        result = importer.import_csv(ROOT / "sample_data" / "sample_meals.csv")
        self.assertEqual((result.ok, result.errors), (40, []))

    def test_error_log_file(self):
        path = importer.write_error_log(["Row 2: bad"], self.dir / "logs" / "e.log")
        self.assertEqual(path.read_text(encoding="utf-8"), "Row 2: bad\n")
        empty = importer.write_error_log([], self.dir / "none.log")
        self.assertIn("No errors", empty.read_text(encoding="utf-8"))


class ExporterTests(unittest.TestCase):
    def setUp(self):
        self.meals = MealStore(ROOT / "sample_data" / "sample_meals.json").load()

    def test_markdown_contains_sections(self):
        text = exporter.to_markdown(self.meals)
        for heading in ["# Weekly Meal Plan Report", "## Summary", "## Daily Overview", "## Grocery List", "## Warnings"]:
            self.assertIn(heading, text)

    def test_text_report_mentions_warnings(self):
        text = exporter.to_text(self.meals)
        self.assertIn("AUDIT LOG", text)
        self.assertIn("Saturday", text)
        self.assertIn("over the 2500", text)

    def test_reports_work_on_empty_plan(self):
        self.assertIn("Monday: nothing planned yet.", exporter.to_markdown([]))
        self.assertIn("Total meals: 0", exporter.to_markdown([]))
        self.assertIn("Meals     : 0", exporter.to_text([]))

    def test_csv_export_can_be_reimported(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "back.csv"
            path.write_text(exporter.to_csv_text(self.meals), encoding="utf-8", newline="")
            result = importer.import_csv(path)
        self.assertEqual(result.errors, [])
        self.assertEqual(result.ok, len(self.meals))
        self.assertEqual([m.name for m in result.meals], [m.name for m in self.meals])

    def test_export_all_writes_three_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            files = exporter.export_all([make_meal(1)], Path(tmp) / "out")
            self.assertEqual(sorted(f.suffix for f in files), [".csv", ".md", ".txt"])
            self.assertTrue(all(f.exists() and f.stat().st_size > 0 for f in files))


@unittest.skipUnless(plotting.matplotlib_available(), "matplotlib not installed")
class PlottingTests(unittest.TestCase):
    def test_charts_are_written(self):
        meals = MealStore(ROOT / "sample_data" / "sample_meals.json").load()
        with tempfile.TemporaryDirectory() as tmp:
            files = plotting.plot_all(meals, tmp)
            self.assertEqual(len(files), 2)
            for f in files:
                self.assertGreater(f.stat().st_size, 1000)

    def test_charts_work_with_no_meals(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(len(plotting.plot_all([], tmp)), 2)


if __name__ == "__main__":
    unittest.main()
